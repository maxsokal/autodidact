<?php
/**
 * Admin "Welcome" page content component
 *
 * Footer.
 *
 * @package    Reykjavik
 * @copyright  WebMan Design, Oliver Juhas
 *
 * @since    1.0.0
 * @version  1.0.0
 */





?>

</div> <!-- /.welcome-content -->

<p><small><em><?php esc_html_e( 'You can disable this page in Appearance &raquo; Customize &raquo; Theme Options &raquo; Others.', 'reykjavik' ); ?></em></small></p>
